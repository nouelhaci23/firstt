import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import {
  Margin,
  Padding,
  Color,
  Border,
  FontFamily,
  FontSize,
} from "../GlobalStyles";

const FrameComponent4 = ({ style }) => {
  return (
    <View style={[styles.frameParent, style]}>
      <View style={[styles.thurstonHighSchoolParent, styles.parentSpaceBlock]}>
        <Text style={[styles.thurstonHighSchool, styles.schoolcraftStFlexBox]}>
          THURSTON HIGH SCHOOL
        </Text>
        <Text
          style={[styles.schoolcraftSt, styles.schoolcraftStFlexBox]}
        >{`26255 Schoolcraft St `}</Text>
        <Text style={[styles.redfordCharterTwp, styles.schoolcraftStFlexBox]}>
          Redford Charter Twp, MI 48239
        </Text>
      </View>
      <View
        style={[
          styles.schoolcraftStParent,
          styles.mt20,
          styles.parentSpaceBlock,
        ]}
      >
        <Text
          style={[styles.redfordCharterTwp, styles.schoolcraftStFlexBox]}
        >{`26255 Schoolcraft St `}</Text>
        <Text style={[styles.redfordCharterTwp, styles.schoolcraftStFlexBox]}>
          Redford Charter Twp, MI 48239
        </Text>
        <Text
          style={[styles.redfordCharterTwp, styles.schoolcraftStFlexBox]}
        >{`26255 Schoolcraft St `}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  mt20: {
    marginTop: Margin.m_md,
  },
  parentSpaceBlock: {
    paddingBottom: Padding.p_xs,
    paddingTop: Padding.p_xs,
    paddingLeft: Padding.p_2xs,
    width: 340,
    borderWidth: 1,
    borderStyle: "solid",
    backgroundColor: Color.chocolate_200,
    borderRadius: Border.br_sm,
  },
  schoolcraftStFlexBox: {
    width: 351,
    justifyContent: "center",
    display: "flex",
    textAlign: "center",
    color: Color.navy,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_lg,
    alignItems: "center",
  },
  thurstonHighSchool: {
    height: 20,
  },
  schoolcraftSt: {
    height: 22,
  },
  redfordCharterTwp: {
    height: 26,
  },
  thurstonHighSchoolParent: {
    borderColor: "#b79640",
  },
  schoolcraftStParent: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    borderColor: "#f1b56f",
  },
  frameParent: {
    alignItems: "center",
  },
});

export default FrameComponent4;
