import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const EHH = ({ style }) => {
  return <Text style={[styles.ehh, style]}>EHH</Text>;
};

const styles = StyleSheet.create({
  ehh: {
    fontSize: FontSize.size_2xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.white,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 172,
  },
});

export default EHH;
