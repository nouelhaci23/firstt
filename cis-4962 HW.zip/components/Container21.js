import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { FontFamily, Color, FontSize } from "../GlobalStyles";

const Container21 = () => {
  return (
    <View style={[styles.rectangleParent, styles.ml40]}>
      <View style={styles.frameChild} />
      <Text style={styles.saturday}>Saturday</Text>
      <Text style={[styles.jan2023, styles.textFlexBox]}>Jan 2023</Text>
      <Text style={[styles.text, styles.textFlexBox]}>21</Text>
      <View style={styles.frameChild} />
      <Text style={styles.saturday}>Saturday</Text>
      <Text style={[styles.jan2023, styles.textFlexBox]}>Jan 2023</Text>
      <Text style={[styles.text, styles.textFlexBox]}>21</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  textFlexBox: {
    fontFamily: FontFamily.poppinsRegular,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    left: 0,
    position: "absolute",
    width: 90,
  },
  frameChild: {
    top: 0,
    backgroundColor: Color.gainsboro,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    left: 0,
    position: "absolute",
    height: 90,
    width: 90,
  },
  saturday: {
    top: 11,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.black,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    fontSize: FontSize.size_base,
    left: 0,
    position: "absolute",
    width: 90,
  },
  jan2023: {
    top: 65,
    color: Color.darkslateblue,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.poppinsRegular,
  },
  text: {
    top: 17,
    fontSize: FontSize.size_5xl,
    color: Color.darkgray_100,
    height: 52,
  },
  rectangleParent: {
    height: 90,
    width: 90,
  },
});

export default Container21;
