import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const SectionCard = () => {
  return (
    <View style={styles.frameParent}>
      <View style={styles.image202301192241103574Parent}>
        <Image
          style={styles.image202301192241103574Icon}
          resizeMode="cover"
          source={require("../assets/image-20230119-224110357-4.png")}
        />
        <Text style={[styles.text, styles.ml1]}>.</Text>
      </View>
      <View style={styles.icons8Alarm481Wrapper}>
        <Image
          style={styles.icons8Alarm481}
          resizeMode="cover"
          source={require("../assets/icons8alarm48-1.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  ml1: {
    marginLeft: 1,
  },
  image202301192241103574Icon: {
    width: 72,
    height: 28,
  },
  text: {
    fontSize: FontSize.size_4xl,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.slategray,
    textAlign: "center",
  },
  image202301192241103574Parent: {
    flexDirection: "row",
  },
  icons8Alarm481: {
    width: 48,
    height: 48,
  },
  icons8Alarm481Wrapper: {
    padding: Padding.p_xs,
    flexDirection: "row",
  },
  frameParent: {
    position: "absolute",
    top: 21,
    right: 0,
    left: 0,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    height: 67,
    overflow: "hidden",
    paddingLeft: Padding.p_xs,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
  },
});

export default SectionCard;
