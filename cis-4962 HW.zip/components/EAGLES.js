import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const EAGLES = ({ style }) => {
  return <Text style={[styles.eagles, style]}>EAGLES</Text>;
};

const styles = StyleSheet.create({
  eagles: {
    fontSize: FontSize.size_2xl,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.white,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 172,
  },
});

export default EAGLES;
