import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const PMNOT2 = ({ style }) => {
  return <Text style={[styles.pmNot, style]}>1 PM - NOT AVAILABLE</Text>;
};

const styles = StyleSheet.create({
  pmNot: {
    alignSelf: "stretch",
    fontSize: FontSize.size_3xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.navy,
    textAlign: "center",
  },
});

export default PMNOT2;
