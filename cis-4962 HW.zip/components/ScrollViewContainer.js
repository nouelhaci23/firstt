import * as React from "react";
import { ScrollView, StyleSheet, View, Text } from "react-native";
import Container21 from "../components/Container21";
import { Margin, FontFamily, Color, FontSize } from "../GlobalStyles";

const ScrollViewContainer = () => {
  return (
    <ScrollView
      style={[styles.frameParent, styles.mt16]}
      horizontal
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.frameScrollView1Content}
    >
      <View style={styles.rectangleParent}>
        <View style={styles.frameChild} />
        <Text style={styles.thursday}>Thursday</Text>
        <Text style={[styles.jan2023, styles.textFlexBox]}>Jan 2023</Text>
        <Text style={[styles.text, styles.textFlexBox]}>19</Text>
      </View>
      <Container21 />
      <Container21 />
      <Container21 />
      <Container21 />
      <Container21 />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  ml40: {
    marginLeft: Margin.m_lg,
  },
  frameScrollView1Content: {
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  textFlexBox: {
    fontFamily: FontFamily.poppinsRegular,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    left: 0,
    position: "absolute",
    width: 90,
  },
  frameChild: {
    top: 0,
    backgroundColor: Color.gray_100,
    borderStyle: "solid",
    borderColor: "#041dff",
    borderWidth: 1,
    left: 0,
    position: "absolute",
    height: 90,
    width: 90,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  thursday: {
    top: 10,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.black,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    fontSize: FontSize.size_base,
    left: 0,
    position: "absolute",
    width: 90,
  },
  jan2023: {
    top: 65,
    color: Color.darkslateblue,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.poppinsRegular,
  },
  text: {
    top: 16,
    fontSize: FontSize.size_5xl,
    color: Color.navy,
    height: 52,
  },
  rectangleParent: {
    height: 90,
    width: 90,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  frameParent: {
    backgroundColor: Color.maroon,
    width: "100%",
    overflow: "hidden",
  },
});

export default ScrollViewContainer;
