import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const FrameComponent2 = ({ style }) => {
  return (
    <View style={[styles.homelessShelterParent, style]}>
      <Text style={styles.homelessShelter}>{`HOMELESS SHELTER `}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  homelessShelter: {
    position: "absolute",
    top: 5,
    left: 1,
    fontSize: FontSize.size_xl,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtrabold,
    color: Color.black,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 313,
  },
  homelessShelterParent: {
    borderRadius: Border.br_sm,
    backgroundColor: Color.chocolate_300,
    height: 32,
    overflow: "hidden",
    width: 313,
  },
});

export default FrameComponent2;
