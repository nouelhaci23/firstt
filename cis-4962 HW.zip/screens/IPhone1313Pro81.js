import * as React from "react";
import { useState } from "react";
import {
  Image,
  StyleSheet,
  View,
  ScrollView,
  Text,
  Dimensions,
  Pressable,
  TouchableHighlight,
} from "react-native";
import Carousel from "react-native-reanimated-carousel";
import EAGLES from "../components/EAGLES";
import EHH from "../components/EHH";
import FrameComponent2 from "../components/FrameComponent2";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent from "../components/FrameComponent";
import FrameComponent4 from "../components/FrameComponent4";
import FrameComponent3 from "../components/FrameComponent3";
import PMNOT2 from "../components/PMNOT2";
import PMNOT1 from "../components/PMNOT1";
import PMNOT from "../components/PMNOT";
import SectionCard from "../components/SectionCard";
import ScrollViewContainer from "../components/ScrollViewContainer";
import {
  Margin,
  Padding,
  FontFamily,
  Color,
  Border,
  FontSize,
} from "../GlobalStyles";

const IPhone1313Pro81 = () => {
  const [frameCarouselItems, setFrameCarouselItems] = useState([
    <EAGLES />,
    <EHH />,
  ]);
  const [frameCarousel1Items, setFrameCarousel1Items] = useState([
    <FrameComponent2 />,
    <FrameComponent1 />,
    <FrameComponent />,
  ]);
  const [dayItems, setDayItems] = useState([
    <FrameComponent4 />,
    <FrameComponent3 />,
  ]);
  const [frameCarousel2Items, setFrameCarousel2Items] = useState([
    <PMNOT2 />,
    <PMNOT1 />,
    <PMNOT />,
  ]);

  return (
    <View style={styles.iphone1313Pro81}>
      <SectionCard />
      <View
        style={[
          styles.frameParent,
          styles.wrapperFlexBox,
          styles.frameParentSpaceBlock,
          styles.frameShadowBox,
          styles.framePosition,
        ]}
      >
        <View style={[styles.groupWrapper, styles.wrapperFlexBox]}>
          <Image
            style={styles.frameChild}
            resizeMode="cover"
            source={require("../assets/group-12.png")}
          />
        </View>
        <View
          style={[
            styles.layer1Wrapper,
            styles.wrapperFlexBox,
            styles.frameParentSpaceBlock,
          ]}
        >
          <Image
            style={styles.layer1Icon}
            resizeMode="cover"
            source={require("../assets/layer1.png")}
          />
        </View>
        <View style={[styles.groupContainer, styles.layer3WrapperLayout]}>
          <Image
            style={styles.groupIcon}
            resizeMode="cover"
            source={require("../assets/group.png")}
          />
        </View>
        <View style={[styles.layer3Wrapper, styles.layer3WrapperLayout]}>
          <Image
            style={styles.layer3Icon}
            resizeMode="cover"
            source={require("../assets/layer-3.png")}
          />
        </View>
      </View>
      <ScrollView
        style={[styles.frameGroup, styles.framePosition]}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollViewContent}
      >
        <View style={[styles.welcomeWrapper, styles.welcomeLayout]}>
          <Text
            style={[
              styles.welcome,
              styles.welcomeTypo,
              styles.welcomePosition,
              styles.welcomeLayout,
            ]}
          >
            WELCOME
          </Text>
        </View>
        <View style={[styles.chooseAnOrganizationDateWrapper, styles.mt16]}>
          <Text
            style={[styles.chooseAnOrganization, styles.typeOfEventFlexBox]}
          >{`CHOOSE AN ORGANIZATION & DATE`}</Text>
        </View>
        <View style={[styles.frameWrapper, styles.mt16]}>
          <View style={[styles.frameSpaceBlock, styles.wrapperBg]}>
            <Carousel
              width={Dimensions.get("window").width * 0.44}
              height={93}
              vertical="true"
              mode="normal"
              data={frameCarouselItems}
              renderItem={({ item }) => item}
            />
          </View>
        </View>
        <View style={[styles.typeOfEventWrapper, styles.mt16]}>
          <Text style={[styles.typeOfEvent, styles.typeOfEventFlexBox]}>
            TYPE OF EVENT
          </Text>
        </View>
        <View style={[styles.frameContainer, styles.mt16]}>
          <View style={styles.container}>
            <Carousel
              width={Dimensions.get("window").width * 0.85}
              height={130}
              vertical="true"
              mode="parallax"
              data={frameCarousel1Items}
              renderItem={({ item }) => item}
            />
          </View>
        </View>
        <ScrollViewContainer />
        <View style={[styles.dayWrapper, styles.mt16]}>
          <View style={styles.day}>
            <Carousel
              width={368}
              height={228}
              vertical="true"
              mode="normal"
              data={dayItems}
              renderItem={({ item }) => item}
            />
          </View>
        </View>
        <View style={[styles.frameLayout, styles.mt16]}>
          <View style={[styles.frameLayout, styles.frameSpaceBlock]}>
            <Carousel
              width={387}
              height={93}
              vertical="true"
              mode="normal"
              data={frameCarousel2Items}
              renderItem={({ item }) => item}
            />
          </View>
        </View>
        <View style={[styles.frameParent1, styles.mt16]}>
          <TouchableHighlight
            style={[
              styles.frameTouchablehighlight,
              styles.makeMyReservationPosition,
              styles.wrapperBg,
              styles.frameShadowBox,
            ]}
            underlayColor="#fff"
            activeOpacity={0.2}
            onPress={() => {}}
          >
            <View />
          </TouchableHighlight>
          <Text
            style={[
              styles.makeMyReservation,
              styles.makeMyReservationPosition,
              styles.welcomeTypo,
            ]}
          >
            Make My Reservation
          </Text>
        </View>
      </ScrollView>
      <View style={[styles.iphone1313Pro81Child, styles.welcomePosition]} />
    </View>
  );
};

const styles = StyleSheet.create({
  mt16: {
    marginTop: Margin.m_sm,
  },
  frameScrollViewContent: {
    flexDirection: "column",
    paddingHorizontal: 0,
    paddingVertical: 20,
  },
  wrapperFlexBox: {
    justifyContent: "space-between",
    height: 52,
  },
  frameParentSpaceBlock: {
    paddingHorizontal: Padding.p_xl,
    justifyContent: "space-between",
    height: 52,
  },
  frameShadowBox: {
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
  },
  framePosition: {
    left: 0,
    position: "absolute",
    right: 0,
  },
  layer3WrapperLayout: {
    width: 65,
    overflow: "hidden",
    justifyContent: "space-between",
    height: 52,
  },
  welcomeLayout: {
    height: 36,
    width: 389,
  },
  welcomeTypo: {
    textAlign: "center",
    fontFamily: FontFamily.poppinsRegular,
  },
  welcomePosition: {
    top: 0,
    left: 0,
    position: "absolute",
  },
  typeOfEventFlexBox: {
    justifyContent: "center",
    display: "flex",
    alignItems: "center",
    textAlign: "center",
    fontFamily: FontFamily.poppinsRegular,
    top: 0,
    left: 0,
    position: "absolute",
  },
  wrapperBg: {
    backgroundColor: Color.chocolate_100,
    overflow: "hidden",
  },
  frameSpaceBlock: {
    paddingBottom: Padding.p_2xl,
    paddingTop: Padding.p_3xs,
    height: 93,
    borderRadius: Border.br_md,
    alignItems: "center",
  },
  makeMyReservationPosition: {
    width: 333,
    left: 29,
    position: "absolute",
  },
  frameChild: {
    width: 42,
    height: 35,
  },
  groupWrapper: {
    paddingHorizontal: Padding.p_lg,
    paddingVertical: Padding.p_sm,
    overflow: "hidden",
    justifyContent: "space-between",
    height: 52,
  },
  layer1Icon: {
    width: 32,
    height: 28,
  },
  layer1Wrapper: {
    paddingVertical: 13,
    overflow: "hidden",
  },
  groupIcon: {
    width: 26,
    height: 33,
  },
  groupContainer: {
    paddingHorizontal: 22,
    paddingTop: 9,
    paddingBottom: Padding.p_2xs,
    flexDirection: "row",
  },
  layer3Icon: {
    width: 33,
    height: 28,
  },
  layer3Wrapper: {
    paddingLeft: Padding.p_lg,
    paddingTop: Padding.p_md,
    paddingRight: 3,
    paddingBottom: Padding.p_md,
  },
  frameParent: {
    bottom: 0,
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowRadius: 25,
    elevation: 25,
    paddingVertical: 0,
    flexDirection: "row",
  },
  welcome: {
    fontSize: FontSize.size_4xl,
    color: Color.chocolate_100,
  },
  welcomeWrapper: {
    backgroundColor: "rgba(180, 180, 180, 0)",
    overflow: "hidden",
  },
  chooseAnOrganization: {
    fontSize: FontSize.size_2xl,
    width: 390,
    color: Color.chocolate_100,
  },
  chooseAnOrganizationDateWrapper: {
    backgroundColor: "rgba(187, 187, 187, 0)",
    height: 29,
    width: 390,
    overflow: "hidden",
  },
  frameWrapper: {
    backgroundColor: "rgba(122, 120, 120, 0)",
    paddingHorizontal: 109,
    paddingVertical: Padding.p_3xs,
    overflow: "hidden",
  },
  typeOfEvent: {
    fontSize: FontSize.size_lg,
    color: Color.darkslateblue,
    width: 389,
  },
  typeOfEventWrapper: {
    backgroundColor: "rgba(193, 182, 182, 0)",
    height: 21,
    width: 389,
    overflow: "hidden",
  },
  container: {
    backgroundColor: "rgba(255, 255, 255, 0)",
    height: 130,
    padding: Padding.p_xs,
    alignItems: "center",
    overflow: "hidden",
  },
  frameContainer: {
    backgroundColor: "rgba(211, 195, 195, 0)",
    height: 132,
    paddingHorizontal: 28,
    overflow: "hidden",
    paddingVertical: 0,
  },
  day: {
    width: 368,
    height: 228,
    paddingHorizontal: 14,
    paddingVertical: Padding.p_xs,
    alignItems: "center",
  },
  dayWrapper: {
    backgroundColor: "rgba(181, 102, 102, 0)",
    paddingHorizontal: Padding.p_sm,
    overflow: "hidden",
    paddingVertical: 0,
  },
  frameLayout: {
    width: 387,
    overflow: "hidden",
  },
  frameTouchablehighlight: {
    top: 6,
    borderRadius: 15,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowRadius: 4,
    elevation: 4,
    height: 48,
  },
  makeMyReservation: {
    top: 11,
    fontSize: 25,
    color: Color.white,
  },
  frameParent1: {
    backgroundColor: "rgba(240, 126, 43, 0)",
    height: 59,
    width: 390,
    overflow: "hidden",
  },
  frameGroup: {
    top: 96,
    bottom: 60,
    backgroundColor: "#f8f8f8",
    overflow: "hidden",
    flex: 1,
  },
  iphone1313Pro81Child: {
    height: 20,
    overflow: "hidden",
    right: 0,
    top: 0,
  },
  iphone1313Pro81: {
    backgroundColor: Color.white,
    width: "100%",
    height: 1145,
    flex: 1,
  },
});

export default IPhone1313Pro81;
